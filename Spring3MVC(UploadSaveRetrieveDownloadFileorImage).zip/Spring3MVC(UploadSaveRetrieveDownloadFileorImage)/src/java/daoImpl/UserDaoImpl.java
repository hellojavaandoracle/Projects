/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package daoImpl;

import dao.UserDao;
import java.util.List;
import model.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author gaurav
 */
@Repository
public class UserDaoImpl implements UserDao {

    
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    
    @Override
    public void save(User uu) {
            Session session = sessionFactory.getCurrentSession();
	    session.save(uu);
    }

    @Override
    public List<User> list() {
            Session session = sessionFactory.getCurrentSession();
		List<User> user = null;
		try {
			user = (List<User>)session.createQuery("from User").list();
                      
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
    }

    @Override
    public void update(Integer id, User uu) {
            Session session = sessionFactory.getCurrentSession();
             User user = (User)session.get(User.class, id);
                 user.setFile_name(uu.getFile_name());
                 user.setFile_content_type(uu.getFile_content_type());
                 user.setFile_content(uu.getFile_content());
             session.update(user);
   } 
    
    @Override
    public void remove(Integer id) {
            Session session = sessionFactory.getCurrentSession();
	    User user = (User)session.get(User.class, id);
	    session.delete(user);
    }
    
    
  
    
}
