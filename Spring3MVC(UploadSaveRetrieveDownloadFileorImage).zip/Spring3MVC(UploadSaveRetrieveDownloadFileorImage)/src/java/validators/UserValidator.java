package validators;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import model.User;
import org.springframework.validation.ValidationUtils;

public class UserValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
		//just validate the User instances
		return User.class.isAssignableFrom(clazz);

	}

	@Override
	public void validate(Object target, Errors errors) {
		
		User uu = (User)target;
                
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username",
			"required.username", "Field name is required.");
             
	}
	
}