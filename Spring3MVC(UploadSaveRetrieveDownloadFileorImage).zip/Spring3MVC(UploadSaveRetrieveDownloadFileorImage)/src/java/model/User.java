/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Blob;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 *
 * @author gaurav
 */
@Entity
@Table(name = "springFileDemo")
public class User {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
   
    @Column(name = "username")
    private String username;
    
    @Column(name = "file_name")
    private String file_name;
    
    @Column(name = "file_content_type")
    private String file_content_type;
    
    @Lob 
    @Column(name ="file_content", columnDefinition="longblob")
    private Blob  file_content;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getFile_content_type() {
        return file_content_type;
    }

    public void setFile_content_type(String file_content_type) {
        this.file_content_type = file_content_type;
    }

    public Blob getFile_content() {
        return file_content;
    }

    public void setFile_content(Blob file_content) {
        this.file_content = file_content;
    }
    
    
}
