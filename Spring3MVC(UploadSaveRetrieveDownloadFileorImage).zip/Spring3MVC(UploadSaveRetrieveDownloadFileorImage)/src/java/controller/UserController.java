package controller;

import java.io.*;
import java.sql.*;
import java.util.*;

import javax.servlet.http.*;
import model.User;


import org.apache.commons.io.IOUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import service.UserManager;
import validators.UserValidator;

@Controller
public class UserController {
	
	@Autowired
	private UserManager userManager;

        public void setUserManager(UserManager userManager) {
            this.userManager = userManager;
        }

        @Autowired
        UserValidator userValidator;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(userValidator);
	}	
        
        
        @RequestMapping("/home")
	public ModelAndView index(ModelMap map, HttpServletRequest request) {
		try {
			map.addAttribute("user", new User());
                        
                        String filepath = request.getSession().getServletContext().getRealPath("/").concat("retrievefile");
                
                        List<User> user = userManager.list();
                          for(User uu : user)
                       {
                          int id = uu.getId();
                          String filename = uu.getFile_name();
                          Blob bb = uu.getFile_content();
                          byte[] data = bb.getBytes(1,(int)bb.length());
                          
                          createFolder(id, filename, data, filepath);
                       }
                        
                        map.addAttribute("userList", user);
            	}catch(Exception e) {
			e.printStackTrace();
		}

                return new ModelAndView("documents","command",new User());
	}

        
        
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(
			@ModelAttribute("user") User user, BindingResult result,
			@RequestParam("file") MultipartFile file, ModelMap mp) {
		
	       userValidator.validate(user, result);
        
           if(result.hasErrors() || file.getSize()==0){
                mp.addAttribute("fileErr", "Please select a file!");
                return "documents";
           }
           
           else {
               
           	try {
			Blob blob = Hibernate.createBlob(file.getInputStream());

                        user.setFile_name(file.getOriginalFilename());
                        user.setFile_content_type(file.getContentType());
                        user.setFile_content(blob);
                        
			userManager.save(user);
                        
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/home.htm";
           }     
	}

        
        @RequestMapping(value = "/update/{Id}")
	public String update(@PathVariable("Id") Integer id,
			@ModelAttribute("user") User user,
			@RequestParam("file2") MultipartFile file, ModelMap mp) {
		
          if(file.getSize()==0){
                mp.addAttribute("fileErr2", "Please select a file!");
                return "documents";
           }
           
           else {
               
           	try {
			Blob blob = Hibernate.createBlob(file.getInputStream());

                        user.setFile_name(file.getOriginalFilename());
                        user.setFile_content_type(file.getContentType());
                        user.setFile_content(blob);
                        
			userManager.update(id, user);
                        
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/home.htm";
           }     
	}
        
        
        
	@RequestMapping("/download/{Id}/{filename}")
	public String download(@PathVariable("Id") Integer id, 
                     @PathVariable("filename") String filename, HttpServletResponse response,
                     HttpServletRequest request) {
		
		try {
                        response.setContentType("APPLICATION/OCTET-STREAM"); 
			response.setHeader("Content-Disposition", "inline;filename=\"" +filename+ "\"");
			
                        OutputStream out = response.getOutputStream();
                        
                       String path = request.getSession().getServletContext().getRealPath("retrievefile")+"\\"+id+"\\"+filename;
                       File ff=new File(path);
                       byte b[]=new byte[(int) ff.length()];

                       FileInputStream fin=new FileInputStream(ff);  
                       fin.read(b);

                       IOUtils.write(b, out);
                       out.flush();
                       out.close();
                       fin.close();
                        
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return null;
	}


        
       @RequestMapping("/remove/{Id}")
	public String remove(@PathVariable("Id")
			Integer id, HttpServletRequest request) {
		
		userManager.remove(id);
                
                String path = request.getSession().getServletContext().getRealPath("retrievefile");
                File ff = new File(path+"\\"+id);
                    if (ff.isDirectory()) {
                             File fff[] = ff.listFiles();
                               for (int ii=0; ii<fff.length; ii++) {
                                        fff[ii].delete();
                               }                                   
                    }    
                ff.delete();
		
		return "redirect:/home.htm";
	}
	
       
        
    private void createFolder(int id, String filename, byte[] data, String path) throws IOException
   {
        String filePath=path;
        File ff=new File(filePath+"\\"+id);
        if(!ff.exists()){
             ff.mkdirs();     //here, we are creating retrieve directory to store retrieve image       
         }
        
        OutputStream outputStream = new FileOutputStream(ff+"\\"+filename);    // here, we are writing data into filename
        IOUtils.write(data, outputStream);
        outputStream.flush();
        outputStream.close();
   }
        
}
