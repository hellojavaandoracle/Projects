/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceImpl;

import dao.UserDao;
import java.util.List;
import model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import service.UserManager;

/**
 *
 * @author gaurav
 */
public class UserManagerImpl implements UserManager {

    @Autowired
    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }
    
    
    @Override
    @Transactional
    public void save(User uu) {
            userDao.save(uu);
    }

    @Override
    @Transactional
    public List<User> list() {
           return userDao.list();
    }

    @Override
    @Transactional
    public void remove(Integer id) {
           userDao.remove(id);
    }

    @Override
    @Transactional
    public void update(Integer id, User user) {
           userDao.update(id, user);
    }
    
}
